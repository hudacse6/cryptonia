import { Schema, model, Document } from 'mongoose'

const schema = new Schema({
    name: String,
    image: String,
    nft: String
})

interface IImage extends Document {
    name: string;
    image: string;
    nft: string;
}

export default model<IImage>('Image', schema)