import path from 'path'
import { Request, Response } from 'express'
import Image from 'src/models/Image';
import { v4 as uuidv4 } from 'uuid';
import { UploadedFile } from "express-fileupload";
import * as fs from 'fs';

export const saveImage = async (req: Request, res: Response) => {
    const file = req.files;

    if (file) {
        try {
            let f = file.image as UploadedFile
            const name = uuidv4() + path.extname(f.name)
            const catObj = {
                name: name,
                image: `uploads/${name}`,
                nft: `uploads/${name}.json`
            }
            const metadataOng = {
                ...req.body,
                animation_url: `${process.env.DOMAIN}/uploads/${name}`
            }

            let metadata = JSON.stringify(metadataOng);

            const image = new Image(catObj);
            const imageSave = await image.save();

            if (imageSave._id) {
                f.mv(`uploads/${name}`, err => {
                    if (err) return res.status(400).send({ message: err })
                })
                fs.writeFile(`uploads/${name}.json`, metadata, () => { });
                return res.status(201).send({ message: 'Cat saved!' })
            }
        } catch (error) {
            console.log(error);
        }
    } else {
        return res.status(400).send({ message: 'Something went wrong!' })

    }
}