import { Router } from 'express'
import { saveImage } from 'src/controllers/images/images.controller'

const router = Router()

router.route('/save-cat').post(saveImage)


export default router;