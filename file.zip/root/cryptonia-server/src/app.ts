import express from 'express'
import dotenv from 'dotenv'
import morgan from 'morgan'
import path from 'path'
import cors from 'cors'
//routes
import IndexRoutes from './routes/index'
import fileupload from 'express-fileupload'
export const dir = path.join(__dirname, '');


dotenv.config();
const app = express();

//settings
app.set('port', process.env.PORT || 8000);

// middlewares
app.use(morgan('dev'))
app.use(express.json());
app.use(fileupload())

app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header(
        "Access-Control-Allow-Headers",
        "Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method"
    );
    res.header(
        "Access-Control-Allow-Methods",
        "GET, POST, OPTIONS, PUT, PATCH,  DELETE"
    );
    res.header("Allow", "GET, POST, OPTIONS, PATCH, DELETE");
    app.use(cors());
    next();
});

app.get('/', (req, res) => {
    return res.status(200).json({message: 'IPFS server cryptoniakittens.com'})
})

app.use('/api', IndexRoutes)
// this folder for app will be used to store public files
app.use('/api/uploads', express.static(path.resolve('uploads')));

export default app;